import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejercicio08',
  templateUrl: './ejercicio08.page.html',
  styleUrls: ['./ejercicio08.page.scss'],
})
export class Ejercicio08Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
