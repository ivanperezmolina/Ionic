import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejercicio09',
  templateUrl: './ejercicio09.page.html',
  styleUrls: ['./ejercicio09.page.scss'],
})
export class Ejercicio09Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
