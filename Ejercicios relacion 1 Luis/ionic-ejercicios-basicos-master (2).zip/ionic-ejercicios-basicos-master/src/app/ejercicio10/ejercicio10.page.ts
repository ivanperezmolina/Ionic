import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ejercicio10',
  templateUrl: './ejercicio10.page.html',
  styleUrls: ['./ejercicio10.page.scss'],
})
export class Ejercicio10Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
